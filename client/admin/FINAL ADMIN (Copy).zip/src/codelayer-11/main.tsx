export function Gallery() {
  return (
    <section className="bg-white py-16" data-name="Gallery">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row gap-[32px] items-center justify-center px-[40px] md:px-[120px] relative w-full">
          
          {/* Laptops */}
          <div className="aspect-[362.66/340] flex-[1_0_0] min-h-px min-w-px relative rounded-[16px] overflow-hidden bg-gray-50 border border-gray-100 flex flex-col items-center justify-center text-center p-6">
            <h3 className="text-2xl font-semibold mb-2">Laptops</h3>
            <p className="text-muted-foreground text-sm">High-performance computing solutions</p>
          </div>

          {/* Components */}
          <div className="aspect-[362.66/340] flex-[1_0_0] min-h-px min-w-px relative rounded-[16px] overflow-hidden bg-gray-50 border border-gray-100 flex flex-col items-center justify-center text-center p-6">
            <h3 className="text-2xl font-semibold mb-2">Components</h3>
            <p className="text-muted-foreground text-sm">Build your dream PC</p>
          </div>

          {/* Peripherals */}
          <div className="aspect-[362.66/340] flex-[1_0_0] min-h-px min-w-px relative rounded-[16px] overflow-hidden bg-gray-50 border border-gray-100 flex flex-col items-center justify-center text-center p-6">
            <h3 className="text-2xl font-semibold mb-2">Peripherals</h3>
            <p className="text-muted-foreground text-sm">Enhance your setup</p>
          </div>

        </div>
      </div>
    </section>
  );
}