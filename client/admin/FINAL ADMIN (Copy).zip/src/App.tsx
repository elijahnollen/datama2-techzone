import { useState } from 'react';
import { AdminDashboard } from './components/AdminDashboard';
import { AdminLogin } from './components/AdminLogin';
import { ForgotPassword } from './components/ForgotPassword';
import { ResetPassword } from './components/ResetPassword';
import { Register } from './components/Register';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentPage, setCurrentPage] = useState<'login' | 'forgot-password' | 'reset-password' | 'register'>('login');
  const [resetEmail, setResetEmail] = useState('');

  if (!isAuthenticated) {
    if (currentPage === 'forgot-password') {
      return <ForgotPassword onBack={() => setCurrentPage('login')} />;
    }
    
    if (currentPage === 'reset-password') {
      return <ResetPassword email={resetEmail} onBack={() => setCurrentPage('login')} />;
    }

    if (currentPage === 'register') {
      return (
        <Register 
          onBack={() => setCurrentPage('login')} 
          onRegisterSuccess={() => setCurrentPage('login')}
        />
      );
    }
    
    return (
      <AdminLogin 
        onLogin={() => setIsAuthenticated(true)} 
        onForgotPassword={() => setCurrentPage('forgot-password')}
        onRegister={() => setCurrentPage('register')}
      />
    );
  }

  return <AdminDashboard onLogout={() => setIsAuthenticated(false)} />;
}