import { Search, User, ShoppingCart } from "lucide-react";

function SearchBar() {
  return (
    <div className="flex-[1_0_0] max-w-[600px] px-[20px]">
      <div className="relative w-full">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-full leading-5 bg-[#f3f4f6] placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-blue-500 sm:text-sm"
          placeholder="Search for products..."
        />
      </div>
    </div>
  );
}

function Nav() {
  return (
    <nav className="flex items-center gap-[24px] relative shrink-0" data-name="Nav">
      <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
        <User size={24} strokeWidth={1.5} />
      </button>
      <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
        <ShoppingCart size={24} strokeWidth={1.5} />
      </button>
    </nav>
  );
}

export default function Header() {
  return (
    <header className="flex items-center justify-between px-[64px] py-[16px] bg-white border-b border-gray-100 w-full" data-name="Header">
      <div className="font-['Inter:Black',sans-serif] font-black text-[24px] tracking-tight text-black">
          TechZone
        </div>
  
      <SearchBar />
      
      <Nav />
    </header>
  );
}