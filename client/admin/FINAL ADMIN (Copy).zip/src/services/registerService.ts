/**
 * Registration Service
 * 
 * CONNECT YOUR PHP REGISTRATION HERE
 * 
 * This service handles new admin user registration.
 * 
 * Database: MySQL (The Vault)
 * Backend: PHP
 */

import { api } from './api';

export interface RegisterRequest {
  firstName: string;
  lastName: string;
  address: string;
  employeeRole: string;
  email: string;
  password: string;
  role: string;
}

export interface RegisterResponse {
  success: boolean;
  message: string;
  userId?: number;
}

/**
 * REGISTER NEW ADMIN ACCOUNT
 * 
 * TODO: Connect to your PHP backend
 * Expected PHP endpoint: POST /auth/register.php
 * 
 * PHP should:
 * 1. Validate all input fields
 * 2. Check if email already exists
 * 3. Hash the password using password_hash()
 * 4. Insert into admin_users table
 * 5. Return success with user ID
 * 
 * PHP Query Example:
 * // Check if email exists
 * $stmt = $pdo->prepare("SELECT id FROM admin_users WHERE email = ?");
 * $stmt->execute([$email]);
 * if ($stmt->fetch()) {
 *     // Email already exists
 *     return error
 * }
 * 
 * // Hash password
 * $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
 * 
 * // Insert new admin user
 * $stmt = $pdo->prepare("
 *     INSERT INTO admin_users 
 *     (first_name, last_name, address, employee_role, email, password, role, status, created_at) 
 *     VALUES (?, ?, ?, ?, ?, ?, ?, 'Active', NOW())
 * ");
 * $stmt->execute([
 *     $firstName, 
 *     $lastName, 
 *     $address, 
 *     $employeeRole, 
 *     $email, 
 *     $hashedPassword, 
 *     $role
 * ]);
 * $userId = $pdo->lastInsertId();
 * 
 * PHP Example Response:
 * {
 *   "success": true,
 *   "message": "Account created successfully",
 *   "userId": 123
 * }
 * 
 * OR if email exists:
 * {
 *   "success": false,
 *   "message": "Email already registered"
 * }
 */
export async function registerAdmin(data: RegisterRequest): Promise<RegisterResponse> {
  // ==========================================
  // REPLACE THIS WITH YOUR PHP BACKEND CALL
  // ==========================================
  const response = await api.post<RegisterResponse>('/auth/register', data);
  return response;
}

/**
 * CHECK IF EMAIL EXISTS
 * 
 * TODO: Connect to your PHP backend
 * Expected PHP endpoint: POST /auth/check-email.php
 * 
 * PHP Query Example:
 * SELECT id FROM admin_users WHERE email = ? LIMIT 1
 * 
 * Returns:
 * {
 *   "exists": true/false
 * }
 */
export async function checkEmailExists(email: string): Promise<boolean> {
  const response = await api.post<{ exists: boolean }>('/auth/check-email', { email });
  return response.exists;
}
