/**
 * Password Reset Service
 * 
 * CONNECT YOUR PHP PASSWORD RESET HERE
 * 
 * This service handles direct password reset without email verification.
 * User enters email, then immediately sets new password.
 * 
 * Database: MySQL (The Vault)
 * Backend: PHP
 */

import { api } from './api';

export interface VerifyEmailRequest {
  email: string;
}

export interface ResetPasswordDirectRequest {
  email: string;
  newPassword: string;
}

/**
 * VERIFY EMAIL EXISTS
 * 
 * TODO: Connect to your PHP backend
 * Expected PHP endpoint: POST /auth/verify-email.php
 * 
 * PHP should:
 * 1. Check if email exists in admin_users table
 * 2. Return success if found, error if not
 * 
 * PHP Query Example:
 * SELECT id, email FROM admin_users WHERE email = ? LIMIT 1
 * 
 * PHP Example Response:
 * {
 *   "success": true,
 *   "message": "Email verified",
 *   "data": {
 *     "email": "admin@techzone.com"
 *   }
 * }
 * 
 * OR if not found:
 * {
 *   "success": false,
 *   "message": "Email not found"
 * }
 */
export async function verifyEmail(email: string): Promise<{ exists: boolean }> {
  // ==========================================
  // REPLACE THIS WITH YOUR PHP BACKEND CALL
  // ==========================================
  const response = await api.post<{ exists: boolean }>('/auth/verify-email', { email });
  return response;
}

/**
 * RESET PASSWORD DIRECTLY (No Email Verification)
 * 
 * TODO: Connect to your PHP backend
 * Expected PHP endpoint: POST /auth/reset-password-direct.php
 * 
 * PHP should:
 * 1. Verify email exists in admin_users table
 * 2. Hash the new password using password_hash()
 * 3. Update the admin_users table with new password
 * 4. Return success message
 * 
 * PHP Query Example:
 * // Hash password
 * $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
 * 
 * // Update password
 * UPDATE admin_users 
 * SET password = ?, updated_at = NOW() 
 * WHERE email = ?
 * 
 * PHP Example Response:
 * {
 *   "success": true,
 *   "message": "Password reset successfully"
 * }
 */
export async function resetPasswordDirect(email: string, newPassword: string): Promise<void> {
  // ==========================================
  // REPLACE THIS WITH YOUR PHP BACKEND CALL
  // ==========================================
  await api.post('/auth/reset-password-direct', { 
    email, 
    newPassword 
  });
}