
  # FINAL ADMIN (Copy)

  This is a code bundle for FINAL ADMIN (Copy). The original project is available at https://www.figma.com/design/qnqdceu3vMNADv8R0HyD4Y/FINAL-ADMIN--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  